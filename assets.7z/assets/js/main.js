// let the user see the last cocktail he saw
let currentCocktail = localStorage.getItem("currentCocktail");
let currentIngredient = localStorage.getItem("currentIngredient");
// get a random cocktail when loading page
let randomUrl = "https://www.thecocktaildb.com/api/json/v1/1/random.php";
const NUM_COCKTAIL_PER_CAROUSEL = 10;
// create 2 localStorage data for ingredients
let localIngredientsList = localStorage.getItem("ingredientsList");
let localIngredientsListOptions = localStorage.getItem(
  "ingredientsListOptions"
);

function writeCocktails(cocktails) {
  Object.entries(cocktails).length === 1
    ? writeCocktail(cocktails[0])
    : writeCocktailsList(cocktails);
  //  cocktails.forEach((el) => writeCocktail(el));
}
function writeCocktailsList(cocktails) {
  const paginationContainer = document.querySelector(".pagination");
  let len = Object.entries(cocktails).length;

  let numOfCocktailsLinks = Math.floor(len / NUM_COCKTAIL_PER_CAROUSEL);

  console.log("nombre de cocktails " + len);
  len = len > 10 ? 10 : len;

  // save this request in storage..

  //  localStorage.setItem("cocktailsWithIngredient", cocktails);
  // 0 0 : first eleemnt, first page
  // localStorage.setItem("currentIn_CocktailsWithIngredient", "0,0");

  let arrowLeft = document.querySelector("a.left");
  let arrowRight = document.querySelector("a.right");

  arrowLeft.dataset["id"] = len;
  arrowRight.dataset["id"] = 1;

  [arrowLeft, arrowRight].forEach((el) => {
    el.addEventListener("click", (elem) => {
      elem.preventDefault;
      // get cocktail from storage based on it's key
      getLocalCocktailWithIngredient(elem.target.dataset.id);
    });
  });

  if (numOfCocktailsLinks > 0) {
    for (let i = 1; i < numOfCocktailsLinks + 1; i++) {
      const aLi = document.createElement("li");
      const aLink = document.createElement("a");
      aLink.textContent = i;
      aLink.href = "#";
      aLink.className = "page";
      aLink.dataset.title = i;
      aLi.appendChild(aLink);
      paginationContainer.appendChild(aLi);
    }
  }

  writeCocktail(cocktails[0]);
}

function writeCocktail(cocktail) {
  console.log("here");
  console.log(cocktail);
  console.log("after");
  let cocktailImage = document.querySelector(".cocktail-image");
  let cocktailName = document.querySelector(".cocktail-name > p");
  let cocktailDescription = document.querySelector(".cocktail-description > p");
  let cocktailIngredients = document.querySelector(".cocktail-ingredients");
  let cocktailTags = document.querySelector(".cocktail-tags");
  let cocktailIngredientsList = document.getElementById("ingredientDataList");
  // change image
  cocktailImage.innerHTML = `<img src="${cocktail.strDrinkThumb}" alt="${cocktail.strDrink}" />`;
  cocktailName.textContent = `${cocktail.strDrink}`;
  cocktailDescription.textContent = `${cocktail.strInstructions}`;
  getCocktailIngredients(cocktail).map((x) => {
    const aLink = document.createElement("a");
    aLink.className = "";
    aLink.innerHTML = x;
    aLink.href = "#";

    // Add the event listener
    aLink.addEventListener("click", (el) => {
      el.preventDefault();
      fetchUrlData(
        `https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=${x}`,
        "ingredient"
      );
      localStorage.setItem("currentIngredient", x);
    });

    // Append the button to the created card
    cocktailIngredients.appendChild(aLink);
  });

  cocktailTags.textContent = cocktail.strTags || "";
  //  cocktailIngredientsList.innerHTML = localIngredientsListOptions || "";

  /* default behavior */
  let ingredientListLinks = document.querySelectorAll("a.ingredientList");
}

/**
 *
 * @param {Object cocktail} cocktail a cocktail object to parse, create ingredient datalist in localstorage
 * @returns array : list of ingredients in a cocktails
 */
function getCocktailIngredients(cocktail) {
  let ingredients = [];
  for (const [key, value] of Object.entries(cocktail)) {
    if (key.includes("strIngredient") && value) ingredients.push(value);
    // if value is not in our global list of ingredients
    if (
      localIngredientsList &&
      false === localIngredientsList.includes(value)
    ) {
      localIngredientsList.push(value);
      // add new option so we just have to load it from localStorage instead a recreate it each time
      localIngredientsListOptions.push(
        `<option value="${value}">${value}</option>`
      );
    }
  }

  return ingredients;
}

/**
 *
 * @param {string} url url to fetch data form. If empty, will search for margarita cocktails
 */
function fetchUrlData(
  url = "https://www.thecocktaildb.com/api/json/v1/1/search.php?s=margarita",
  type = "cocktail"
) {
  fetch(url)
    .then((response) => response.json())
    .then((data) => {
      writeCocktails(data.drinks);
    })
    .catch((error) => {
      console.log(error);
    });
}

// get a random data only when page is loaded and not each time application link is activated
if (localStorage.getItem("currentCocktail") !== "") {
  fetchUrlData(randomUrl, "cocktail");
}

function getLocalCocktailWithIngredient(cocktail_id) {
  /* to change to database later, won't work with localStorage here
  writeCocktail(
    Object.entries(localStorage.getItem("cocktailsWithIngredient"))[cocktail_id]
  );
  */
  fetchUrlData(randomUrl, "ingredient");
}
